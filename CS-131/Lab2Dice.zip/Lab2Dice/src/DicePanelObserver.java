/** A public interface can be implemented by any class. * Many graphical user interface components implement  * public interfaces. You must use them to work with the 
* */ GUI features of Java.

public interface DicePanelObserver {

    public void update();

}