import javax.swing.*;

 /** DiceRoller.java
  *
  *  The DiceRoller class will be used to test
  *  the Dice class. 
  * 
  * die3 rolls a 10 sided dice. die4 rolls a 6 sided dice.
  * The program the outputs both dice rolls.
  * 
  *  @author Remah Alshinina
  *  @version 20 Aug. 2020
 */
 

public class DiceRoller
{
	public static void main(String[] args)
	{
		Dice die3;
		die3 = new Dice(10);
		Dice die4;
		die4 = new Dice();
		
		int result3;
		result3 = die3.roll();
		int result4;
		result4 = die4.roll();
		
		System.out.println("First number rolled is " + result3);
		System.out.println("Second number rolled is " + result4);
    }
}
