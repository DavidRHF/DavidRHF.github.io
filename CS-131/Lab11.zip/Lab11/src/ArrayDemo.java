
/**
 * Program to demonstrate the creation and processing of an array.
*/

public class ArrayDemo
{
	public static void main (String[] args)
	{
		// Create the array data
		double[] data;
		data = new double[10];
		
		// Store values in data
		data[0] = 19.95;
		data[1] = 23.95;
		data[2] = 24.95;
		data[3] = 18.95;
		data[4] = 29.95;
		data[5] = 19.95;
		data[6] = 20.00;
		data[7] = 22.99;
		data[8] = 24.95;
		data[9] = 19.95;
				
		// Display the values in data
		for (int i = 0; i < 10; i++)
		{
			System.out.println(data[i]);
		}
	}
}