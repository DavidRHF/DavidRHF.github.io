import java.util.Scanner;
/**
 * Name: Volume and Surface Area Calculations
 * Author: DJ Hazall-Farrell
 * Purpose:To calculate the area and volume of geometric objects
 *
 */
public class ScannerCalculator {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		//declares value holders
		final double PI = 3.14159;
		double radius;
		double height;
		double volume;
		double area;
		
		//Inputs a scanner so the user can declare their own values
		Scanner consoleInput;
		consoleInput = new Scanner(System.in);
		System.out.println("Enter the radius of the cylinder: ");
		radius = consoleInput.nextDouble();
		System.out.println("Enter the height of the cylinder: ");
		height = consoleInput.nextDouble();
		consoleInput.close();
		
		//Calculates values of volume and area 
		volume = PI * (radius * radius) * height;
		area = ((2 * PI) * (radius * radius)) + ((2 * PI) * radius * height);
		
		//Outputs values in structured sentences
		System.out.println("The Radius is " + radius);
		System.out.println("The Height is " + height);
		System.out.println("The Volume is " + volume);
		System.out.println("The Surface area is " + area);

	}

}
