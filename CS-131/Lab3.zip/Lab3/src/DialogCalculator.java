import javax.swing.*;

/**
 * Name: Volume and Surface Area Calculations
 * Author: DJ Hazall-Farrell
 * Purpose:To calculate the area and volume of geometric objects
 *
 */
public class DialogCalculator {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		//declares value holders
		final double PI = 3.14159;
		double radius;
		double height;
		double volume;
		double area;
		
		//Displays a window in which the user can  assign their values to the variables
		String dialogResult;
		dialogResult = JOptionPane.showInputDialog(null, "What is the radius of the cylinder?");
		radius = Double.parseDouble(dialogResult); // Converts dialogResult from String to double
		
		dialogResult = JOptionPane.showInputDialog(null, "What is the height of the cylinder?");
		height = Double.parseDouble(dialogResult); 
		
		//Calculates values of volume and area
		volume = PI * (radius * radius) * height;
		area = ((2 * PI) * (radius * radius)) + ((2 * PI) * radius * height);
		
		//Displays the radius, height, volume and surface area in one window
		JOptionPane.showMessageDialog(null, "The radius is " + radius + "\nThe height is " + height + "\nThe Volume is " + volume + "\nThe Surface area is " + area );

		
	}

}
