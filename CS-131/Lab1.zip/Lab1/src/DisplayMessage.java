import javax.swing.*;

/** 
 *  Displays the string "Hello, World!" by using a JOptionPane MessageDialog.
 * Starting with a simple example, if you just want to show a JOptionPane dialog with a simple text message, all you need is one line of Java source code like: 
JOptionPane.showMessageDialog(frame, "A basic JOptionPane message dialog");

 *
 *  @author David Hazall-Farrell
 *  @version January 22nd, 2024
*/ 

public class DisplayMessage
{
    public static void main(String [] args) 
    {
        // declare and create a JFrame object 
        JFrame myWindow;
        myWindow = new JFrame();
        
        
            // set size of the window and make it visible
        myWindow.setSize(400,300);
        myWindow.setLocation(500, 400);
        myWindow.setTitle("My Second Java Program");
        myWindow.setVisible(true);
        
            // use a message dialog box to display a message
        JOptionPane.showMessageDialog(myWindow, " Name: David Hazall-Farrell \n Email: hazalldr22@bonaventure.edu \n Lab Date: 1/22/2024");
    }
} 
