/*
 *(Modified output from "Hello World", "I am in CS 131!") to
 * 
 *The message "Name: David Hazall-Farrell"
 *  	      "Email: hazalldr22@bonaventure.edu"
 *   	      "Lab Date: 1/22/2024"
 * 
 * @author David Hazall-Farrell
 * @version January 22, 2024
 */
public class HelloWorld
{

    public static void main(String [] args)
    {
    	System.out.println("Name: David Hazall-Farrell");
    	System.out.println("Email: hazalldr22@bonaventure.edu");
    	System.out.println("Lab Date: 1/22/2024");
    }
}

