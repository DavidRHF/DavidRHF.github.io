/** 

 * A simple class to test various methods found in Fun.java 

 * @author  

 * @version  

 * 

 * Note: My testing output varies slightly from that used by your textbook authors. 

 *    This is a matter of personal style; you may use either style (or an equivalent 

 *    one of your own) while you complete this lab. 

 */ 

public class FunctionTester { 

 

    public static void main(String[] args) { 

        System.out.println("sum(4,6) = " + Fun.sum(4,6) + " (expected 10)"); 

        System.out.println("sum(8,2) = " + Fun.sum(8,2) + " (expected 10)"); 

        System.out.println("whosBigger(5,30,60,2,8) = " + Fun.whosBigger(5,30,60,2,8) + " (expected 60)"); 

        System.out.println("whosBigger(40,200,6,324,85) = " + Fun.whosBigger(40,200,6,324,85) + " (expected 324)"); 

        System.out.println("whosBigger(1,5,3,4,2) = " + Fun.whosBigger(1,5,3,4,2) + " (expected 5)"); 

    } 

 

} 