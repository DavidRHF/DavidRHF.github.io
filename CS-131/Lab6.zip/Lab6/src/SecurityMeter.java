import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JButton;

/**
 * SecurityMeter - A program that interactively shows password strengths
 *     
 * @author 
 * @version
 *
 */
public class SecurityMeter implements KeyListener, ActionListener {

    private JFrame frmPasswordChooser;
    private JPasswordField passwordField;
    private JPasswordField passwordConfirmField;
    private JTextField strengthField;
    private JCheckBox clearTextCheckBox;

    /**
     * Main method
     * The structure of this main method is a standard "idiom" for applications with a graphical user interface
     */

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    SecurityMeter window = new SecurityMeter();
                    window.frmPasswordChooser.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public SecurityMeter() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     * This is the method that actually builds the GUI
     * Each component is created, given initial values, and then placed
     * into the larger interface (JFrame) 
     */
    private void initialize() {
        
        //  First build the main window
        
        frmPasswordChooser = new JFrame();
//        frmPasswordChooser.getContentPane().setFont(new Font("Tahoma", Font.BOLD, 18));
        frmPasswordChooser.setTitle("Password Chooser");
        frmPasswordChooser.setBounds(100, 100, 523, 368);
        frmPasswordChooser.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmPasswordChooser.getContentPane().setLayout(null);
        frmPasswordChooser.getContentPane().setBackground(new Color(240,240,240));
        
        // Build the top field to hold the password
        
        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Tahoma", Font.BOLD, 14));
        passwordField.setBounds(47, 58, 177, 32);
        frmPasswordChooser.getContentPane().add(passwordField);
        passwordField.setColumns(10);
        passwordField.addKeyListener(this);  // Identify this class as the one that 
                                             // handles key strokes in this form

        // Give that field a label and attach the two
        
        JLabel label = new JLabel("Password");
        label.setFont(new Font("Tahoma", Font.BOLD, 18));
        label.setBounds(47, 11, 105, 50);
        label.setLabelFor(passwordField);
        frmPasswordChooser.getContentPane().add(label);

        // Build a second field, for the "confirmation" of the password
        
        passwordConfirmField = new JPasswordField();
        passwordConfirmField.setFont(new Font("Tahoma", Font.BOLD, 14));
        passwordConfirmField.setColumns(10);
        passwordConfirmField.setBounds(47, 151, 177, 32);
        passwordConfirmField.setActionCommand("Verify Password");   // Create a label for the action we
                                                                    // wish to perform if the user hits "Enter" here
        passwordConfirmField.addActionListener(this);               // Identify this class as the one to perform that action
        frmPasswordChooser.getContentPane().add(passwordConfirmField);

        // Create (and attach) the label for the second password field
        
        JLabel lblConfirm;
        lblConfirm = new JLabel("Confirm");
        lblConfirm.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblConfirm.setBounds(47, 101, 105, 50);
        lblConfirm.setLabelFor(passwordConfirmField);
        frmPasswordChooser.getContentPane().add(lblConfirm);

        // Create a (mostly hidden) field that will ultimately display the password's strength
        
        strengthField = new JTextField();
        strengthField.setEditable(false);
        strengthField.setFont(new Font("Tahoma", Font.BOLD, 18));
        strengthField.setBackground(new Color(240, 240, 240));
        strengthField.setBounds(245, 58, 231, 32);
        strengthField.setBorder(null);
        strengthField.setColumns(10);
        frmPasswordChooser.getContentPane().add(strengthField);

        // Create the text box that will allow us to reveal passwords if we desire
        
        clearTextCheckBox = new JCheckBox("Show passwords in clear");
        clearTextCheckBox.setBounds(173, 218, 200, 23);
        clearTextCheckBox.setActionCommand("Hide/Show Password");   // Again, identify the command to execute if we check this box
        clearTextCheckBox.addActionListener(this);                  // and indicate that this class will contain the code
        frmPasswordChooser.getContentPane().add(clearTextCheckBox);
        
        // Create the button to ultimately set the password
        
        JButton btnNewButton = new JButton("Set Password");
        btnNewButton.setBounds(173, 267, 120, 23);
        btnNewButton.setActionCommand("Verify Password");   // Make this just like hitting "Enter" in the confirm window
        btnNewButton.addActionListener(this);
        frmPasswordChooser.getContentPane().add(btnNewButton);
    }

    // The next three methods are required if we want to interact with individual
    // keystrokes.  In our case, we only care about reacting when the user releases a key;
    // Thus, the other two methods are empty
    
    @Override
    public void keyPressed(KeyEvent arg0) {
    }

    @Override
    public void keyReleased(KeyEvent arg0) {
        String pw = new String(passwordField.getPassword());  // Get the current password
        evaluate(PasswordUtils.score(pw));   // and figure out what to do with it - first by
                                             // scoring it using student code, and then 
                                             // displaying the strength of the user password
    }

    @Override
    public void keyTyped(KeyEvent arg0) {
    }

    // Handle the two commands specified above
    @Override
    public void actionPerformed(ActionEvent ae) {
//        System.out.println("Executing: " + ae.getActionCommand());
        
        // Hide/Show Password code
        
        if (ae.getActionCommand().equals("Hide/Show Password")) {
            if (clearTextCheckBox.isSelected()) {
                passwordField.setEchoChar((char) 0);    // Show the letters as they are
                passwordConfirmField.setEchoChar((char) 0);
            } else {
                passwordField.setEchoChar((char) 8226); // Show the solid dots for each character (hide the letters)
                passwordConfirmField.setEchoChar((char) 8226);
            }
        }
        
        // Check to see if both passwords are the same
        
        if (ae.getActionCommand().equals("Verify Password")) {
            String pwOrig = new String(passwordField.getPassword());        // Get the two passwords
            String pwConf = new String(passwordConfirmField.getPassword());
            if (pwOrig.equals(pwConf)) {     // See if they have the same letters as each other
                JOptionPane.showMessageDialog(frmPasswordChooser,"Password (hypothetically) changed");
            } else {
                JOptionPane.showMessageDialog(frmPasswordChooser,"Passwords do not match");
            }
        }
        
    }
    
    /**
     * Display a message emblematic of the strength of the password
     * @param s the score for the strength (assumed to be 1-5)
     */
    private void evaluate(int s) {
        // if s is out of range, bring it back into the range
        
        if (s<=1) {
            s = 1;
        } else if (s>=5) {
            s = 5;
        }
        
        // Choose the message (and color) to display - and do so
        
        switch(s) {
        case 1:
            strengthField.setForeground(Color.red);
            strengthField.setText("Very weak");
            break;
        case 2:
            strengthField.setForeground(Color.orange);
            strengthField.setText("Weak");
            break;
        case 3:
            strengthField.setForeground(Color.yellow);
            strengthField.setText("Fair");
            break;
        case 4:
            strengthField.setForeground(Color.blue);
            strengthField.setText("Strong");
            break;
        case 5:
            strengthField.setForeground(Color.green);
            strengthField.setText("Very Strong");
            break;
        default:       // Shouldn't ever happen
            System.err.println("Inconsistent state in SecurityMeter/evaluate");
        }
    }
}
