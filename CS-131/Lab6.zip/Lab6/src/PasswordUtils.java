import java.util.Scanner;
/**
 * PasswordUtils contains a bunch of methods that are useful in determining
 * the strength of passwords.  
 * A main method is provided to exercise (and debug)the methods.
 * 
 * @author <Your name here>
 *
 */

public class PasswordUtils 
{

    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Password to test: ");
        String pw = sc.nextLine();
        
        System.out.println(score(pw) + "/5 rating.");
        
        /*
        if (containsUpperCase(pw)) 
        {
            System.out.println("   ...contains an upper case letter");
        }
        else if (containsLowerCase(pw)) 
        {
            System.out.println("   ...contains a lower case letter");
        }
        else if (containsDigit(pw)) 
        {
            System.out.println("   ...contains a digit");
        }
        else if (containsSpecialChar(pw)) 
        {
            System.out.println("   ...contains a special character");
        }
*/
    }
   /**
    * Determine if the given string contains an upper case letter
    * @param s the string to check
    * @return true if and only if s contains an upper case letter
    */
    public static boolean containsUpperCase(String s) 
    {
        for (int letter = 0; letter < s.length(); letter++) 
        {
            if ("ABCDEFGHIJKLMNOPQRSTUVWXYZ".indexOf(s.charAt(letter)) >= 0) 
            {
                return true;
            }
        }
        return false;
    }
    //Determines if the password has a lower case letter
    public static boolean containsLowerCase(String s) 
    {
        for (int letter = 0; letter < s.length(); letter++) 
        {
            if ("abcdefghijklmnopqrstuvwxyz".indexOf(s.charAt(letter)) >= 0) 
            {
                return true;
            }
        }
        return false;
    }
    //determines if the password has a digit
    public static boolean containsDigit(String s) 
    {
        for (int letter = 0; letter < s.length(); letter++) 
        {
            if ("0123456789".indexOf(s.charAt(letter)) >= 0) 
            {
                return true;
            }
        }
        return false;
    }
    //determines if the password has a special character
    public static boolean containsSpecialChar(String s) 
    {
        for (int letter = 0; letter < s.length(); letter++) 
        {
            if ("!@#$%^&*()_+{}:".indexOf(s.charAt(letter)) >= 0) 
            {
                return true;
            }
        }
        return false;
    }
    public static boolean longEnough(String s) 
    {
        for (int letter = 0; letter < s.length(); letter++) 
        {
            if (letter >= 8) 
            {
                return true;
            }
        }
        return false;
    }
    

    /**
     * Determine the actual strength of a password based upon various tests
     * @param s the password to evaluate
     * @return the strength (on a 1 to 5 scale, 5 is very good) of the password
     */
    public static int score(String s) {
    	int rating = 0;
        if(containsLowerCase(s) == true) {
        	rating++;
        }
        if(containsUpperCase(s) == true) {
        	rating++;
        }
        if(containsDigit(s) == true) {
        	rating++;
        }
        if(containsSpecialChar(s) == true) {
        	rating++;
        }
        if(longEnough(s) == true) {
        	rating++;
        }
    	
    	return rating;
    }
}
