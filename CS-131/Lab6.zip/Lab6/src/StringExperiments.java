import java.util.Scanner;

public class StringExperiments { 

    	public static void main (String[] Args) {
    	/*
    	String empty1 = "empty";
    	String empty2 = "";
    	String empty3 = null;
    	String zero = "0";
    	String blank = " ";
    	String nothing;
    	System.out.println(empty1 .length());
    	*/
    		
    	Scanner console = new Scanner(System.in); 
    	//String name; 
    	//System.out.print("Enter name: ");
    	//name = console.nextLine(); 
    	//System.out.println(name);
    	
    	System.out.println("Give me a sentence.");
    	String sentence;
    	sentence = console.nextLine();
    	
    	int numSpaces = 0;
    	for(int i = 0; i <= sentence.length() - 1; i++) {
    		if(sentence.charAt(i) == ' ') {
    			numSpaces++;
    		}
    	}
    		
    	System.out.println("The sentence, " + sentence + ", contains " + numSpaces + " spaces.");
    	}  
}
