import javax.swing.*;
import java.awt.*;


public class OurPictures {

	public static void main(String[] args) {
		
		JFrame myWindow;
        myWindow = new JFrame();
        
        myWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
            // set size of the window and make it visible
        myWindow.setSize(2000, 2000);
        myWindow.setLocation(400, 150);
        myWindow.setTitle("Shalom");
        myWindow.setVisible(true);
        myWindow.setLayout(new FlowLayout());

        //Set image of myself, along with text
        ImageIcon imgMe = new ImageIcon("DJShroom.jpeg");
        JLabel lblName = new JLabel("Me biting a Shroom!?!?", imgMe, SwingConstants.CENTER);
        lblName.setVerticalTextPosition(SwingConstants.BOTTOM);
        lblName.setHorizontalTextPosition(SwingConstants.CENTER);
        
        //Set image of Aaron, along with text
        ImageIcon imgHe = new ImageIcon("AaronElf.jpg");
        JLabel lblHim = new JLabel("Aaron is an elf!?!?", imgHe, SwingConstants.CENTER);
        lblHim.setVerticalTextPosition(SwingConstants.BOTTOM);
        lblHim.setHorizontalTextPosition(SwingConstants.CENTER);

        //Introduces a frame for my picture
        JPanel DJShroom = new JPanel();
        DJShroom.add(lblName);
        myWindow.getContentPane().add(DJShroom);
        myWindow.pack();

        //Introduces a frame for Aarons picture
        JPanel AaronElf = new JPanel();
        AaronElf.add(lblHim);
        myWindow.getContentPane().add(AaronElf);
        myWindow.pack();

	}
}
