import java.util.Scanner;




public class RunBunco {

		public static void main(String[]args) {

			Scanner scnr = new Scanner(System.in);
			
			//number of players
			int playerNumber = 4;
			int currentPlayer = 1;
			//Number of players and their points
			int playerOnePoints = 0;
			int playerTwoPoints = 0;
			int playerThreePoints = 0;
			int playerFourPoints = 0;
			int tempPoints = 0;
			int roundPoints = 0;
			//Round Number
			int rN = 1;
			
			//while(rN <= 6) {
				while((currentPlayer <= playerNumber) && (rN <= 6)) {
					
					System.out.println("Player " + currentPlayer + "'s turn");
					System.out.println("Press 'Enter' to roll!");
					scnr.nextLine();
					
					if(currentPlayer == 1) {
						tempPoints = countBunco(rN);
						 while(tempPoints != 0) {
							 roundPoints = roundPoints + tempPoints;
							 tempPoints = countBunco(rN); 
							 if(roundPoints >= 21) {
								 tempPoints = 0;
							 }
						 } 
						 playerOnePoints = playerOnePoints + roundPoints;
						 System.out.println("Player 1 scored: " + roundPoints + " points in round " + rN);
						 System.out.println("Player 1's total score is: " + playerOnePoints);
						 roundPoints = 0;
					}
					if(currentPlayer == 2) {
						tempPoints = countBunco(rN);
						 while(tempPoints != 0) {
							 roundPoints = roundPoints + tempPoints;
							 tempPoints = countBunco(rN); 
							 if(roundPoints >= 21) {
								 tempPoints = 0;
							 }
						 } 
						 playerTwoPoints = playerTwoPoints + roundPoints;
						 System.out.println("Player 2 scored: " + roundPoints + " points in round " + rN);
						 System.out.println("Player 2's total score is: " + playerTwoPoints);
						 roundPoints = 0;
					}
					if(currentPlayer == 3) {
						tempPoints = countBunco(rN);
						 while(tempPoints != 0) {
							 roundPoints = roundPoints + tempPoints;
							 tempPoints = countBunco(rN); 
							 if(roundPoints >= 21) {
								 tempPoints = 0;
							 }
						 } 
						 playerThreePoints = playerThreePoints + roundPoints;
						 System.out.println("Player 3 scored: " + roundPoints + " points in round " + rN);
						 System.out.println("Player 3's total score is: " + playerThreePoints);
						 roundPoints = 0;
					}
					if(currentPlayer == 4) {
						tempPoints = countBunco(rN);
						 while(tempPoints != 0) {
							 roundPoints = roundPoints + tempPoints; 
							 tempPoints = countBunco(rN);
							 if(roundPoints >= 21) {
								 tempPoints = 0;
							 }
						 }
						 playerFourPoints = playerFourPoints + roundPoints;
						 System.out.println("Player 4 scored: " + roundPoints + " points in round " + rN);
						 System.out.println("Player 4's total score is: " + playerFourPoints);
						 currentPlayer = 0;
						 rN ++;
						 roundPoints = 0;
					}
					currentPlayer ++;
				}
				
				
				if((playerOnePoints > playerTwoPoints) && (playerOnePoints > playerThreePoints) && (playerOnePoints > playerFourPoints)) {
					System.out.println("Congratulations player 1! You won with a score of " + playerOnePoints + " points!");
				}
				else if((playerTwoPoints > playerOnePoints) && (playerTwoPoints > playerThreePoints) && (playerTwoPoints > playerFourPoints)) {
					System.out.println("Congratulations player 2! You won with a score of " + playerTwoPoints + " points!");
				}
				else if((playerThreePoints > playerTwoPoints) && (playerThreePoints > playerTwoPoints) && (playerThreePoints > playerFourPoints)) {
					System.out.println("Congratulations player 3! You won with a score of " + playerThreePoints + " points!");
				}
				else if((playerFourPoints > playerOnePoints) && (playerFourPoints > playerTwoPoints) && (playerFourPoints > playerThreePoints)) {
					System.out.println("Congratulations player 4! You won with a score of " + playerFourPoints + " points!");
				}
				
			//}			
			
		}
				
				
			private static int countBunco(int rN) {
				
				// Dice 1, 2, and 3
				Dice d1;
				d1 = new Dice();
				Dice d2;
				d2 = new Dice();
				Dice d3;
				d3 = new Dice();
				//Result 1, 2, and 3
				int r1 = d1.roll();
				int r2 = d2.roll();
				int r3 = d3.roll();
				System.out.println("1st Dice:" + r1);
				System.out.println("2nd Dice:" + r2);
				System.out.println("3rd Dice:" + r3);
				
				int total = 0;
				
					if((r1 == rN) && (r2 == rN) && (r3 == rN)) {
						total += 13;
						System.out.println("You got a bunco!");
						//if(total >= 21) {
							//return total;
						//}
						//else{
							//return total += 0;	
							//}
					}
					else if((r1 == r2) && (r1 == r3) && (r2 == r3)) {
						total += 5;
						System.out.println("You got a mini bunco!");
						//if(total >= 21) {
							//return total;
						//}
						//else{
							//return total += 0;	
							//}
					}
					else if(r1 == rN) {
						total++;
						//System.out.println("You got one point!");
						//if(total >= 21) {
							//return total;
						//}
						//else{
							//return total += 0;	
							//}
					}
					else if(r2 == rN) {
						total++;
						//System.out.println("You got one point! Roll again!");
						//if(total >= 21) {
							//return total;
						//}
						//else{
							//return total += 0;	
							//}
					}
					else if(r3 == rN) {
						total++;
						//System.out.println("You got one point! Roll again!");
						//if(total >= 21) {
							//return total;
						//}
						//else{
							//return total += 0;	
							//}
						
					}
					return total;
					
			}
				
					
				
				
				
				
				//currentPlayer ++;
				
					
}		
				
			

