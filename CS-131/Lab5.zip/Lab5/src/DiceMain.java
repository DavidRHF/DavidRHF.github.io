import java.util.Scanner;

public class DiceMain {

	public static void main(String[] args) {
	
		//Establishes the variable used to count all 7s
		int count7;
		count7 = 0;
		
		//Establishes the variable used to count all doubles
		int doubles;
		doubles = 0;
		
		//Scanner for question 16
		Scanner scnr = new Scanner(System.in);
		System.out.println("How many times should the dice be rolled?");
		int answer = scnr.nextInt();
		
		//Continually loops until a specific amount of dice are rolled
		for (int i = 0; i < answer; i++) {  	
		
		//Establishes dice used for the program
		Dice die1;
		die1 = new Dice();
		Dice die2;
		die2 = new Dice();
		
		//Rolls the dice and stores the value
		int result1;
		int result2;
		result1 = die1.roll();
		result2 = die2.roll();
		
		//Calculates sum
		int sum;
		sum = result1 + result2;
		
		//Counts the amount of 7s rolled
		if (sum == 7) {
			count7++;
		}
		
		if (result1 == result2) {
			doubles++;
		}
		
		
		/*
		Scanner scnr = new Scanner(System.in);
		System.out.println("Guess the result!!!");
		int guess = scnr.nextInt();
		Used for question 6
		
		 
		System.out.println("First roll: " + result1);
		System.out.println("Second roll: " + result2);
		System.out.println("sum: " + sum);
		
	
			if (sum > 7) {
				System.out.println("You win!!!");
			} else if (sum < 7) {
		    	System.out.println("You lose!!!");
			} else if (sum == 7) {
				System.out.println("We tie!!!");
			}
			Used in question 8
		*/
		
		}

		//displays amount of 7s rolled
		System.out.println("The number 7 was achieved " + count7 + " times");
		System.out.println("The number of doubles is " + doubles);
		
	}
}
